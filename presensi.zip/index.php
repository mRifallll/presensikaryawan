<?php
header("location: auth/login.php");
